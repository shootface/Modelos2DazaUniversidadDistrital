$("#llorona").click(function () {
    window.location = "inicio/Llorona"
});

$("#elude").click(function () {
    window.location = "inicio/EludeAsteroids"
});

$("#calaveras").click(function () {
    window.location = "inicio/Calaveras"
});

$("#2048").click(function () {
    window.location = "inicio/2048"
});

$("#charizard").click(function () {
    window.location = "inicio/Charizard"
});